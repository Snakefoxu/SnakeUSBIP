# SnakeUSBIP - ARM64 Release Notes

## ⚠️ IMPORTANT: Test-Signed Drivers

The ARM64 drivers included in this release are **test-signed only** (not WHLK certified).

This means you must enable Windows Test Mode before installing the drivers.

### How to Enable Test Mode

1. Open **Command Prompt as Administrator**
2. Run the following command:
   ```
   bcdedit /set testsigning on
   ```
3. **Restart** your computer
4. After reboot, you'll see "Test Mode" watermark on the desktop (bottom-right corner)

### To Disable Test Mode Later

1. Uninstall the drivers first
2. Run as Administrator:
   ```
   bcdedit /set testsigning off
   ```
3. Restart your computer

### Why is this necessary?

Windows requires drivers to be digitally signed with a WHLK (Windows Hardware Lab Kit) certificate to run without test mode. The ARM64 drivers from the upstream `usbip-win2` project have not yet completed this certification process.

The x64 version uses WHLK-certified drivers and does not require test mode.

---


